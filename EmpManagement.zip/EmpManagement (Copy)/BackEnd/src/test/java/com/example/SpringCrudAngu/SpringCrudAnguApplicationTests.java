package com.example.SpringCrudAngu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCrudAnguApplicationTests {

	@Test
	void contextLoads() {
	}

}
