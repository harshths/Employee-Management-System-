package com.example.SpringCrudAngu.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.SpringCrudAngu.entity.Employee;

@Repository
public interface EmpDao extends CrudRepository<Employee, Integer>{
    
}
