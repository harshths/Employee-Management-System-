package com.example.SpringCrudAngu.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.SpringCrudAngu.entity.Employee;
import com.example.SpringCrudAngu.service.EmpService;

@RestController
@CrossOrigin(origins = "http://localhost:4200") 
public class EmpController {

    @Autowired
    private EmpService service;


    @PostMapping("/save")
    public Employee saveEmployee(@RequestBody Employee employee){
        return service.saveData(employee);
    }


    @GetMapping("/getall")
    public List<Employee> getAllData(){
        return service.getAllData();
    }

    @GetMapping("/get/{id}")
    public Optional<Employee> getById(@PathVariable int id){
        return service.getById(id);
    }
    

    @DeleteMapping("/delete/{id}")
    public String deleteById(@PathVariable int id){
        return service.deleteById(id);
    }


    @PutMapping("/update")
    public Employee updateData(@RequestBody Employee employee){
        return service.updateData(employee);
    }

}
