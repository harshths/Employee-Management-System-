package com.example.SpringCrudAngu.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SpringCrudAngu.dao.EmpDao;
import com.example.SpringCrudAngu.entity.Employee;

@Service
public class EmpService {

    @Autowired
    private EmpDao empDao;

    public Employee saveData(Employee employee){
        return empDao.save(employee);
    }

    public List<Employee> getAllData(){
        List<Employee> list = (List<Employee>) empDao.findAll();
        return list;
    }

    public Optional<Employee> getById(int id){
        return empDao.findById(id);
    }
    
    public String deleteById(int id){
        empDao.deleteById(id);
        return "Data from id -> "+id+" has deleted Successfully...";
    }

    public Employee updateData(Employee employee){
        return empDao.save(employee);
    }
}
