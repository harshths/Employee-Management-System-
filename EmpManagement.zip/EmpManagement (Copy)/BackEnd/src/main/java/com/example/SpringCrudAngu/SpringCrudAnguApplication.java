package com.example.SpringCrudAngu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCrudAnguApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCrudAnguApplication.class, args);
	}

}
