import { Component } from '@angular/core';
import { Routes } from '@angular/router';
import { EmpFormComponentComponent } from './component/emp-form-component/emp-form-component.component';
import { EmpListComponentComponent } from './component/emp-list-component/emp-list-component.component';
import { EmpUpdateComponentComponent } from './component/emp-update-component/emp-update-component.component';

export const routes: Routes = [
    {path:"form", component:EmpFormComponentComponent},
    {path:"list", component:EmpListComponentComponent},
    {path:"update/:id", component:EmpUpdateComponentComponent}

];
