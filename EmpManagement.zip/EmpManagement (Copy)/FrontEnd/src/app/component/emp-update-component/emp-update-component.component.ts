import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { EmployeeService } from '../../services/employee.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-emp-update-component',
  imports: [FormsModule],
  templateUrl: './emp-update-component.component.html',
  styleUrl: './emp-update-component.component.css'
})
export class EmpUpdateComponentComponent implements OnInit{

  employee : any = {
      id:0,
      name: '',
      phone: '',
      address: '',
      gender: '',
      department: '',
      skills: ''
    }

  
    constructor(private empService : EmployeeService, private rout : ActivatedRoute, private router : Router){}


  ngOnInit(){
    const idd = this.rout.snapshot.paramMap.get("id");
    if(idd){
    this.employee.id = +idd;

    }
  }
  
    updateData(){
      console.log(this.employee.id);
      this.empService.updateData(this.employee).subscribe(Response => {
        this.router.navigate(['/list']);
  
      })
    }

    

}
