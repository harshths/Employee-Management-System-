import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmpUpdateComponentComponent } from './emp-update-component.component';

describe('EmpUpdateComponentComponent', () => {
  let component: EmpUpdateComponentComponent;
  let fixture: ComponentFixture<EmpUpdateComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EmpUpdateComponentComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EmpUpdateComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
