import { Component } from '@angular/core';
import { Employee } from '../../interfaces/employee';
import { EmployeeService } from '../../services/employee.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-emp-form-component',
  imports: [FormsModule],
  templateUrl: './emp-form-component.component.html',
  styleUrl: './emp-form-component.component.css'
})
export class EmpFormComponentComponent {

  employee : any = {
    name: '',
    phone: '',
    address: '',
    gender: '',
    department: '',
    skills: ''
  }

  constructor(private empService : EmployeeService){}

  addData(){
    this.empService.addData(this.employee).subscribe(Response => {
      window.location.href = "/list";

    })
  }
}
