import { Component, OnInit } from '@angular/core';
import { Employee } from '../../interfaces/employee';
import { EmployeeService } from '../../services/employee.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-emp-list-component',
  imports: [FormsModule, CommonModule],
  templateUrl: './emp-list-component.component.html',
  styleUrl: './emp-list-component.component.css'
})
export class EmpListComponentComponent implements OnInit{
 

emp : Employee[] = [];


  ngOnInit(){
    this.showData();
  }
  
  constructor(private empService : EmployeeService, private router: Router){}

  showData(){
    this.empService.showData().subscribe(data =>{
      this.emp = data;
    });
  }

  deleteData(id : number){
    this.empService.deleteData(id).subscribe(Response => {
      // this.emp = this.emp.filter(emp => emp.id !== id);
      this.router.navigate(['/list'], { replaceUrl: true });

    })
  }

  updateKiValue(id : number){
    this.router.navigate(['/update', id]);
  }

}
