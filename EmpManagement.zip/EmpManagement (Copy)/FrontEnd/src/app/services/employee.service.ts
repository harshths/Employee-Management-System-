import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Employee } from '../interfaces/employee';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor(private http : HttpClient) { }

  url = "http://localhost:8080";

  showData():Observable<Employee[]>{
    return this.http.get<Employee[]>(this.url+"/getall");
  }

  addData(employee : Employee){
    return this.http.post(this.url+"/save", employee);
  }

  deleteData(id : number){
    return this.http.delete(this.url+"/delete/"+id);
  }

  updateData(employee : Employee){
    return this.http.put(this.url+"/update", employee)
  }

  getById(id : number){
    return this.http.get(this.url+"/get/"+id);
  }

  myid : any;
}
