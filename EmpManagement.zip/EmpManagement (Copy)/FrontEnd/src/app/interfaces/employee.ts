export interface Employee {
    id : number;
    name : string;
    phone : string;
    address : string;
    gender : string;
    department : string;
    skills : string;
    
}
// | Field      | Type         | Null | Key | Default | Extra |
// +------------+--------------+------+-----+---------+-------+
// | id         | int          | NO   | PRI | NULL    |       |
// | address    | varchar(255) | YES  |     | NULL    |       |
// | department | varchar(255) | YES  |     | NULL    |       |
// | gender     | varchar(255) | YES  |     | NULL    |       |
// | name       | varchar(255) | YES  |     | NULL    |       |
// | phone      | varchar(255) | YES  |     | NULL    |       |
// | skills     | varchar(255) | YES  |     | NULL    |       |
// +------------+--------------+------+-----+---------+-------+
